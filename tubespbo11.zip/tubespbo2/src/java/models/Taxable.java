/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author hp
 */
public interface Taxable {
    double TAX_RATE = 0.12; // 12% tax rate

    double calculateTax(); // Method to calculate tax
}
