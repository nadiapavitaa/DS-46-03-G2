/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author zitas
 */

public class Customer extends User {
    private String username;

    // Constructor
    public Customer(String username, String email, String password) {
        super(email, password);
        this.username = username;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    // Implement login
    @Override
    public boolean login(String email, String password) {
        // Logic to verify email and password for a customer (simulasi)
        return this.getEmail().equals(email) && this.getPassword().equals(password);
    }

    // Method for signup
    public static Customer signup(String username, String email, String password) {
        // Logic to create and save a new customer (simulasi)
        return new Customer(username, email, password);
    }
}

