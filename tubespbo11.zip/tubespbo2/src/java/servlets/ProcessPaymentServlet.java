/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Passenger;

/**
 *
 * @author Asus
 */
@WebServlet(name = "ProcessPaymentServlet", urlPatterns = {"/processPayment"})
public class ProcessPaymentServlet extends HttpServlet {
      protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ticketID = request.getParameter("ticketID");
        String fullName = request.getParameter("fullName");
        String phoneNumber = request.getParameter("phoneNumber");
        String email = request.getParameter("email");

        // Lakukan proses penyimpanan data atau validasi di sini
        request.setAttribute("ticketID", ticketID);
        request.setAttribute("fullName", fullName);
        request.setAttribute("phoneNumber", phoneNumber);

        // Redirect ke halaman konfirmasi pembayaran
        request.getRequestDispatcher("confirmation.jsp").forward(request, response);
    }
}

