/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

public abstract class Payment {
    private String paymentID;
    private double amount;

    // Constructor
    public Payment(String paymentID, double amount) {
        this.paymentID = paymentID;
        this.amount = amount;
    }

    // Getters and Setters
    public String getPaymentID() { return paymentID; }
    public void setPaymentID(String paymentID) { this.paymentID = paymentID; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    // Abstract method to process payment
    public abstract String processPayment();
}
