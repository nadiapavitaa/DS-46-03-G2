/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/payment")
public class PaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ticketID = request.getParameter("ticketID");
        int numberOfSeats = Integer.parseInt(request.getParameter("numberOfSeats"));
        String selectedSeats = request.getParameter("selectedSeats");
        String passengerDetails = ""; // Detail penumpang

        // Ambil data penumpang berdasarkan jumlah kursi
        for (int i = 1; i <= numberOfSeats; i++) {
            String name = request.getParameter("name" + i);
            String identity = request.getParameter("identity" + i);
            passengerDetails += "Passenger " + i + ": " + name + " (" + identity + ")<br>";
        }

        // Hitung total harga (contoh)
        double pricePerSeat = 2.0; // Ambil harga per kursi dari database
        double totalPrice = pricePerSeat * numberOfSeats;
        double tax = totalPrice * 0.12; // Pajak 12%

        // Simpan atribut untuk ditampilkan di payment.jsp
        request.setAttribute("details", "Flight from JKT to TKY on 2025-01-31 at 13.00-14.00");
        request.setAttribute("numberOfSeats", numberOfSeats);
        request.setAttribute("selectedSeats", selectedSeats);
        request.setAttribute("passengerDetails", passengerDetails);
        request.setAttribute("tax", tax);
        request.setAttribute("totalPrice", totalPrice + tax);

        RequestDispatcher dispatcher = request.getRequestDispatcher("payment.jsp");
        dispatcher.forward(request, response);
    }
}
