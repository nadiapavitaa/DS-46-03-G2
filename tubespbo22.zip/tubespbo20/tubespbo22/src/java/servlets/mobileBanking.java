/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import dao.DBconnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 *
 * @author asus
 */

@WebServlet("/mobileBanking")
public class mobileBanking extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accountNumber = request.getParameter("accountNumber");
        String status;
        String paymentCode = null;
        boolean success = false;
        String invoiceNumber = "INV" + System.currentTimeMillis();  // Generate a mock invoice number for demonstration

        try {
            // Validasi input
            if (accountNumber == null || accountNumber.isEmpty() || accountNumber.length() != 10) {
                throw new IllegalArgumentException("Invalid Account Number. Must be 10 digits.");
            }

            // Generate 16-digit payment code
            paymentCode = String.format("%016d", (long) (Math.random() * Math.pow(10, 16)));
            status = "Payment Code generated successfully!";
            success = true;

        } catch (IllegalArgumentException e) {
            status = "Error: " + e.getMessage();
        }

        // Set attributes to forward to the JSP page
        request.setAttribute("paymentStatus", status);
        request.setAttribute("success", success);
        request.setAttribute("invoiceNumber", invoiceNumber);
        if (paymentCode != null) {
            request.setAttribute("paymentCode", paymentCode);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("paymentStatus.jsp");
        dispatcher.forward(request, response);
    }
}