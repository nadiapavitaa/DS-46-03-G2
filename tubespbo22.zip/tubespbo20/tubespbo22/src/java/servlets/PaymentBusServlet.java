/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import models.PaymentBus;
import models.Bus;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/paymentBus")
public class PaymentBusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ticketID = request.getParameter("ticketID");
        int numberOfSeats = Integer.parseInt(request.getParameter("numberOfSeats"));

        Bus bus = Bus.getTicketByID(ticketID);
        if (bus == null) {
            response.sendRedirect("bus.jsp");
            return;
        }

        double totalPrice = bus.getPrice() * numberOfSeats;
        StringBuilder passengerDetails = new StringBuilder();
        for (int i = 1; i <= numberOfSeats; i++) {
            String name = request.getParameter("name" + i);
            String identityNumber = request.getParameter("identity" + i);
            passengerDetails.append("Passenger ").append(i).append(": ").append(name)
                    .append(" (").append(identityNumber).append(")<br>");
        }

        PaymentBus payment = PaymentBus.createPayment(ticketID);

        request.setAttribute("totalPrice", totalPrice);
        request.setAttribute("passengerDetails", passengerDetails.toString());
        request.setAttribute("payment", payment);
        request.setAttribute("bus", bus);

        RequestDispatcher dispatcher = request.getRequestDispatcher("paymentBus.jsp");
        dispatcher.forward(request, response);
    }
}
