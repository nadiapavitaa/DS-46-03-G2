/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import models.Customer;
import dao.DBconnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author zitas
 */

@WebServlet("/signup")
public class signup extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection connection = DBconnection.getConnection()) {
            String checkEmailSql = "SELECT email FROM customers WHERE email = ?";
            PreparedStatement checkEmailStatement = connection.prepareStatement(checkEmailSql);
            checkEmailStatement.setString(1, email);
            ResultSet emailResultSet = checkEmailStatement.executeQuery();

            if (emailResultSet.next()) {
                response.setContentType("text/html");
                response.getWriter().println("<h3>Email sudah terdaftar. Silakan <a href='login.jsp'>login</a>.</h3>");
            } else {
                String checkUsernameSql = "SELECT username FROM customers WHERE username = ?";
                PreparedStatement checkUsernameStatement = connection.prepareStatement(checkUsernameSql);
                checkUsernameStatement.setString(1, username);
                ResultSet usernameResultSet = checkUsernameStatement.executeQuery();

                if (usernameResultSet.next()) {
                    response.setContentType("text/html");
                    response.getWriter().println("<h3>Username sudah digunakan pengguna lain. Silakan ganti username.</h3>");
                } else {
                    String insertSql = "INSERT INTO customers (username, email, password) VALUES (?, ?, ?)";
                    PreparedStatement insertStatement = connection.prepareStatement(insertSql);
                    insertStatement.setString(1, username);
                    insertStatement.setString(2, email);
                    insertStatement.setString(3, password);

                    int rowsInserted = insertStatement.executeUpdate();

                    if (rowsInserted > 0) {
                        Customer customer = new Customer(username, email, password);
                        HttpSession session = request.getSession();
                        session.setAttribute("customer", customer);
                        response.sendRedirect("main.jsp");
                    } else {
                        response.setContentType("text/html");
                        response.getWriter().println("<h3>Terjadi kesalahan saat pendaftaran. Silakan coba lagi.</h3>");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<h3>Terjadi kesalahan! Silakan coba lagi nanti.</h3>");
        }
    }
}

