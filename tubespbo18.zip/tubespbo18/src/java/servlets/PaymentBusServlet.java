/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import models.PaymentBus;
import models.Flight;
import models.Bus;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
/**
 *
 * @author zitas
 */
@WebServlet("/paymentBus")
public class PaymentBusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ticketID = request.getParameter("ticketID");
        String paymentID = request.getParameter("paymentID");
        String action = request.getParameter("action");
        String type = request.getParameter("type"); // Either "Flight" or "Bus"
        int numberOfSeats = Integer.parseInt(request.getParameter("numberOfSeats"));

        double totalPrice = 0.0;
        double tax = 0.0;
        String details = "";
        StringBuilder passengerDetails = new StringBuilder();

        
        if (type.equals("Flight")) {
            Flight flight = Flight.getTicketByID(ticketID); // Implement getTicketByID to fetch details
            if (flight != null) {
                totalPrice = flight.getPrice() * numberOfSeats;
                tax = flight.calculateTax(totalPrice); // Calculate tax using Taxable interface
                totalPrice += tax;
                details = "Flight from " + flight.getOrigin() + " to " + flight.getDestination() +
                          " on " + flight.getDate() + " at " + flight.getTime();
            }
        } else if (type.equals("Bus")) {
            Bus bus = Bus.getTicketByID(ticketID); // Implement getTicketByID to fetch details
            if (bus != null) {
                totalPrice = bus.getPrice() * numberOfSeats;
                details = "Bus from " + bus.getOrigin() + " to " + bus.getDestination() +
                          " on " + bus.getDate() + " at " + bus.getTime();
            }
        }

        // Collect passenger details
        for (int i = 1; i <= numberOfSeats; i++) {
            String name = request.getParameter("name" + i);
            String identityNumber = request.getParameter("identity" + i);
            passengerDetails.append("Passenger ").append(i).append(": ").append(name)
                    .append(" (").append(identityNumber).append(")<br>");
        }

        request.setAttribute("totalPrice", totalPrice);
        request.setAttribute("tax", tax); // Only applies to flights
        request.setAttribute("details", details);
        request.setAttribute("passengerDetails", passengerDetails.toString());
        request.setAttribute("numberOfSeats", numberOfSeats);

        if (ticketID != null) {
            Bus flight = Bus.getTicketByID(ticketID);
            PaymentBus payment = PaymentBus.createPayment(ticketID);
            
            request.setAttribute("flight", flight);
            request.setAttribute("payment", payment);
            RequestDispatcher dispatcher = request.getRequestDispatcher("paymentBus.jsp");
            dispatcher.forward(request, response);
        }else{
            response.sendRedirect("bus.jsp");
        }
    }
}