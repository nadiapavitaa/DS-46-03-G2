/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package servlets;

import models.Bus;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/bus")
public class BusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String origin = request.getParameter("origin");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date"); // Format: YYYY-MM-DD

        int numberOfSeats = 0;
        try {
            numberOfSeats = Integer.parseInt(request.getParameter("numberOfSeats"));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        List<Bus> busTickets = Bus.searchTicket(origin, destination, date);

        if (!busTickets.isEmpty()) {
            for (Bus bus : busTickets) {
                double basePrice = Bus.calculateTotalPrice(bus.getPrice(), numberOfSeats);
                double tax = bus.calculateTax();
                double totalPriceWithTax = basePrice + tax;
                bus.setPrice(totalPriceWithTax); // Update price to total price
            }
        }

        request.setAttribute("busTickets", busTickets);
        request.setAttribute("numberOfSeats", numberOfSeats);

        RequestDispatcher dispatcher = request.getRequestDispatcher("bus.jsp");
        dispatcher.forward(request, response);
    }
}
