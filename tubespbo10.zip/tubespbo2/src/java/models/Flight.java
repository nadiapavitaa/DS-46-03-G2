/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import dao.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Flight extends Ticket implements Taxable {
    private String planeID;
    private String planeClass;

    // Constructor
    public Flight(String ticketID, String origin, String destination, double price, int seat, String date, String time, String planeID, String planeClass) {
        super(ticketID, origin, destination, price, seat, date, time);
        this.planeID = planeID;
        this.planeClass = planeClass;
    }
    
    public double calculateTax() {
        return this.getPrice() * TAX_RATE; // Calculate 12% of the price
    }

    // Getters and Setters
    public String getPlaneID() { return planeID; }
    public void setPlaneID(String planeID) { this.planeID = planeID; }

    public String getPlaneClass() { return planeClass; }
    public void setPlaneClass(String planeClass) { this.planeClass = planeClass; }

    // Method to search tickets
    public static List<Flight> searchTicket(String origin, String destination, String date, String planeClass) {
        List<Flight> flightTickets = new ArrayList<>();
        String sql = "SELECT * FROM tiket_pesawat WHERE origin = ? AND destination = ? AND date = ? AND planeClass = ?";

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, origin);
            statement.setString(2, destination);
            statement.setString(3, date);
            statement.setString(4, planeClass);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                flightTickets.add(new Flight(
                    resultSet.getString("ticketID"),
                    resultSet.getString("origin"),
                    resultSet.getString("destination"),
                    resultSet.getDouble("price"),
                    resultSet.getInt("seat"),
                    resultSet.getString("date"),
                    resultSet.getString("time"),
                    resultSet.getString("planeID"),
                    resultSet.getString("planeClass")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flightTickets;
    }

    // Calculate total price
    public static double calculateTotalPrice(double pricePerSeat, int numberOfSeats) {
        return pricePerSeat * numberOfSeats;
    }
    
}
