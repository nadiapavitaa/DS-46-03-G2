/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;
import dao.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author pavita
 */
public class Payment {
    private String paymentID;
    private String ticketID;
    //private double amount;

    public Payment(String paymentID, String ticketID) {
        this.paymentID = paymentID;
        this.ticketID = ticketID;
    }

    public String getPaymentID() {
        return paymentID;
    }

    public String getTicketID() {
        return ticketID;
    }


    // Buat entri baru di tabel payment
    public static Payment createPayment(String ticketID) {
        String paymentID = generatePaymentID();
        String sql = "INSERT INTO payment (paymentID, ticketID, status) VALUES (?, ?, 'Failed')";

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, paymentID);
            statement.setString(2, ticketID);
            statement.executeUpdate();
            return new Payment(paymentID, ticketID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    private static String generatePaymentID(){
        String newID = "PY01";
        String sql = "SELECT paymentID FROM payment ORDER BY paymentID DESC LIMIT 1";
        
        try (Connection connection = DBconnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()){
                String lastID = resultSet.getString("paymentID");
                int idNumber = Integer.parseInt(lastID.substring(2));
                idNumber++;
                newID = String.format("PY%02d", idNumber);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        return newID;
    }
    
    public static boolean updatePaymentStatus(String paymentID, String status) {
    String sql = "UPDATE payment SET status = ? WHERE paymentID = ?";
    try (Connection connection = DBconnection.getConnection();
         PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setString(1, status);
        statement.setString(2, paymentID);
        int rowsUpdated = statement.executeUpdate();
        return rowsUpdated > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

}
