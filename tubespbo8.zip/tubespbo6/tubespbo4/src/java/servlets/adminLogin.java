/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import models.Admin;
import dao.DBconnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author zitas
 */
@WebServlet("/adminLogin")
public class adminLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        try (Connection connection = DBconnection.getConnection()) {
            String query = "SELECT * FROM admin WHERE email = ? AND role = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, role);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String storedPassword = resultSet.getString("password");

                if (storedPassword.equals(password)) {
                    Admin admin = new Admin(email, password, role);

                    HttpSession session = request.getSession();
                    session.setAttribute("user", admin);

                    if (role.equalsIgnoreCase("viewer")) {
                        response.sendRedirect("viewer.jsp");
                    } else if (role.equalsIgnoreCase("editor")) {
                        response.sendRedirect("editor.jsp");
                    }
                } else {
                    response.setContentType("text/html");
                    response.getWriter().println("<h3>Password salah. Silakan coba lagi.</h3>");
                }
            } else {
                response.setContentType("text/html");
                response.getWriter().println("<h3>Email atau role tidak ditemukan.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<h3>Terjadi kesalahan. Silakan coba lagi nanti.</h3>");
        }
    }
}
