/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import models.Customer;
import dao.DBconnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/login")
public class login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection connection = DBconnection.getConnection()) {
            String checkEmailSql = "SELECT * FROM customers WHERE email = ?";
            PreparedStatement checkEmailStatement = connection.prepareStatement(checkEmailSql);
            checkEmailStatement.setString(1, email);
            ResultSet emailResultSet = checkEmailStatement.executeQuery();

            if (emailResultSet.next()) {
                String storedPassword = emailResultSet.getString("password");

                if (storedPassword.equals(password)) {
                    Customer customer = new Customer(
                        emailResultSet.getString("username"),
                        emailResultSet.getString("email"),
                        emailResultSet.getString("password")
                    );
                    HttpSession session = request.getSession();
                    session.setAttribute("customer", customer);
                    response.sendRedirect("main.jsp");
                } else {
                    response.setContentType("text/html");
                    response.getWriter().println("<h3>Password salah. Silakan coba lagi.</h3>");
                }
            } else {
                response.setContentType("text/html");
                response.getWriter().println("<h3>Email belum terdaftar. Silakan <a href='signup.jsp'>sign up</a>.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().println("<h3>Terjadi kesalahan. Silakan coba lagi nanti.</h3>");
        }
    }
}
