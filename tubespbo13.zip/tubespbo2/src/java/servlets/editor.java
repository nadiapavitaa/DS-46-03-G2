/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DBconnection;

@WebServlet("/editor")
public class editor extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String tableName = request.getParameter("tableName");
        String action = request.getParameter("action");
        String rowData = request.getParameter("rowData");
        String condition = request.getParameter("condition");

        try (Connection connection = DBconnection.getConnection();
             Statement statement = connection.createStatement()) {

            if ("addRow".equalsIgnoreCase(action)) {
                // Tambah baris
                String[] values = rowData.split(","); // Pisahkan data berdasarkan koma
                for (int i = 0; i < values.length; i++) {
                    values[i] = "'" + values[i].trim().replace("'", "\\'") + "'"; // Tambahkan tanda kutip dan escape karakter
                }
                String formattedValues = String.join(",", values);

                // Hitung jumlah kolom tabel menggunakan query DESCRIBE
                String columnQuery = "DESCRIBE " + tableName;
                try (Statement columnStatement = connection.createStatement();
                     ResultSet columnResultSet = columnStatement.executeQuery(columnQuery)) {

                    int columnCount = 0;
                    while (columnResultSet.next()) {
                        columnCount++;
                    }

                    // Validasi jumlah data yang dimasukkan
                    if (values.length != columnCount) {
                        response.getWriter().println("<p>Error: Jumlah data yang dimasukkan tidak sesuai dengan jumlah kolom tabel.</p>");
                        return;
                    }

                    String sql = "INSERT INTO " + tableName + " VALUES (" + formattedValues + ")";
                    statement.executeUpdate(sql);
                    response.getWriter().println("<p>Baris berhasil ditambahkan ke tabel " + tableName + ".</p>");
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.getWriter().println("<p>Error: " + e.getMessage() + "</p>");
                }
            } else if ("editRow".equalsIgnoreCase(action)) {
                // Edit baris
                if (condition == null || condition.trim().isEmpty()) {
                    response.getWriter().println("<p>Error: Kondisi tidak boleh kosong untuk mengedit baris.</p>");
                    return;
                }

                if (rowData == null || rowData.trim().isEmpty()) {
                    response.getWriter().println("<p>Error: Data baris tidak boleh kosong untuk mengedit baris.</p>");
                    return;
                }

                String[] values = rowData.split(",");
                StringBuilder formattedRowData = new StringBuilder();

                try {
                    // Ambil daftar kolom dari tabel
                    String columnQuery = "DESCRIBE " + tableName;
                    try (Statement columnStatement = connection.createStatement();
                         ResultSet columnResultSet = columnStatement.executeQuery(columnQuery)) {

                        int columnIndex = 0;
                        while (columnResultSet.next()) {
                            if (columnIndex >= values.length) break; // Jika nilai kurang dari jumlah kolom, hentikan

                            String columnName = columnResultSet.getString("Field"); // Ambil nama kolom
                            String value = "'" + values[columnIndex].trim().replace("'", "\\'") + "'"; // Escape tanda kutip
                            formattedRowData.append(columnName).append("=").append(value).append(",");
                            columnIndex++;
                        }

                        // Jika jumlah kolom lebih banyak daripada nilai input
                        if (columnIndex < values.length) {
                            response.getWriter().println("<p>Error: Jumlah nilai input lebih banyak dari jumlah kolom tabel.</p>");
                            return;
                        }

                        // Hapus koma terakhir
                        formattedRowData.setLength(formattedRowData.length() - 1);
                    }

                    // Buat query UPDATE
                    String sql = "UPDATE " + tableName + " SET " + formattedRowData + " WHERE " + condition;
                    int rowsAffected = statement.executeUpdate(sql);

                    if (rowsAffected > 0) {
                        response.getWriter().println("<p>Baris dengan kondisi " + condition + " berhasil diperbarui di tabel " + tableName + ".</p>");
                    } else {
                        response.getWriter().println("<p>Tidak ada baris yang cocok dengan kondisi: " + condition + ".</p>");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    response.getWriter().println("<p>Error: " + e.getMessage() + "</p>");
                }
                
            } else if ("deleteRow".equalsIgnoreCase(action)) {
                // Validasi kondisi
                if (condition == null || condition.trim().isEmpty()) {
                    response.getWriter().println("<p>Error: Kondisi tidak boleh kosong untuk menghapus baris.</p>");
                    return; // Hentikan eksekusi jika kondisi kosong
                }

                // Pastikan kondisi spesifik untuk ID
                String sql = "DELETE FROM " + tableName + " WHERE " + condition;
                try {
                    // Eksekusi query
                    int rowsAffected = statement.executeUpdate(sql);
                    if (rowsAffected > 0) {
                        response.getWriter().println("<p>Baris dengan kondisi " + condition + " berhasil dihapus dari tabel " + tableName + ".</p>");
                    } else {
                        response.getWriter().println("<p>Tidak ada baris yang cocok dengan kondisi: " + condition + ".</p>");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    response.getWriter().println("<p>Error: " + e.getMessage() + "</p>");
                }

            } else {
                response.getWriter().println("<p>Aksi tidak valid.</p>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("<p>Error: " + e.getMessage() + "</p>");
        }
    }
}
