/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author zitas
 */

public class Admin extends User {
    private String role;

    // Constructor
    public Admin(String email, String password, String role) {
        super(email, password);
        this.role = role;
    }

    // Getters and Setters
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Override login
    @Override
    public boolean login(String email, String password) {
        return this.getEmail().equals(email) 
            && this.getPassword().equals(password) 
            && (this.role.equalsIgnoreCase("viewer") || this.role.equalsIgnoreCase("editor"));
    }
}

