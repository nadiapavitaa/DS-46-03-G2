/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.text.NumberFormat;
import java.util.Locale;

public class Ticket {
    private String ticketID;
    private String origin;
    private String destination;
    private double price;
    private int seat;
    private String date;
    private String time;

    // Constructor
    public Ticket(String ticketID, String origin, String destination, double price, int seat, String date, String time) {
        this.ticketID = ticketID;
        this.origin = origin;
        this.destination = destination;
        this.price = price;
        this.seat = seat;
        this.date = date;
        this.time = time;
    }

    // Getters and Setters
    public String getTicketID() { return ticketID; }
    public void setTicketID(String ticketID) { this.ticketID = ticketID; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getSeat() { return seat; }
    public void setSeat(int seat) { this.seat = seat; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    
    public class CurrencyFormatter {
        public static String formatToRupiah(double amount) {
            NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
            return formatter.format(amount);
        }
    }
}

