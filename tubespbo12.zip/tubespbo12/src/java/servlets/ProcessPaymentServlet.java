/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Passenger;
import dao.DBconnection;
import javax.servlet.RequestDispatcher;
import models.Bus;

/**
 *
 * @author Asus
 */
@WebServlet(name = "ProcessPaymentServlet", urlPatterns = {"/processPayment"})
public class ProcessPaymentServlet extends HttpServlet {
      protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String ticketID = request.getParameter("ticketID");
    String seatsToBookParam = request.getParameter("seatsToBook"); // Ambil nilai dari request
    int seatsToBook = 0;

    try {
        if (seatsToBookParam != null && !seatsToBookParam.trim().isEmpty()) {
            seatsToBook = Integer.parseInt(seatsToBookParam); // Parse jika tidak null/empty
        } else {
            throw new IllegalArgumentException("Seats to book is missing or invalid.");
        }
    } catch (NumberFormatException e) {
        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid number of seats.");
        return;
    }

    List<Bus> busTickets = (List<Bus>) getServletContext().getAttribute("busTickets");
    Bus selectedBus = null;

    for (Bus bus : busTickets) {
        if (bus.getTicketID().equals(ticketID)) {
            selectedBus = bus;
            break;
        }
    }

    if (selectedBus != null) {
        double totalPrice = selectedBus.getPrice() * seatsToBook;
        request.setAttribute("selectedBus", selectedBus);
        request.setAttribute("seatsToBook", seatsToBook);
        request.setAttribute("totalPrice", totalPrice);
    } else {
        response.sendError(HttpServletResponse.SC_NOT_FOUND, "Selected bus not found.");
        return;
    }

    RequestDispatcher dispatcher = request.getRequestDispatcher("confirmation.jsp");
    dispatcher.forward(request, response);
    }
}



