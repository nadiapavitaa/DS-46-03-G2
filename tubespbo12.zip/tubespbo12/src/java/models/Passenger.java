/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import dao.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
/**
 *
 * @author Asus
 */
public class Passenger {
    private String fullName;
    private String phoneNumber;
    private String email;

    // Constructor
    public Passenger(String fullName, String phoneNumber, String email) {
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    // Getters and Setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Insert Passenger Data into the Database
    public static boolean insertPassenger(String fullName, String phoneNumber, String email) {
        String sql = "INSERT INTO passengers (fullName, phoneNumber, email) VALUES (?, ?, ?)";
        boolean isInserted = false;

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the SQL query
            statement.setString(1, fullName);
            statement.setString(2, phoneNumber);
            statement.setString(3, email);

            // Execute the query
            int rowsAffected = statement.executeUpdate();
            isInserted = rowsAffected > 0; // Check if rows were affected
        } catch (Exception e) {
            e.printStackTrace();
        }

        return isInserted;
    }
}
