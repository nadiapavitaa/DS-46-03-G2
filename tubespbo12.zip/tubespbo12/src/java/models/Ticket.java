/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.text.NumberFormat;
import java.util.Locale;

public class Ticket {
    private String ticketID;
    private String origin;
    private String destination;
    private double price;
    private int seat;
    private String date;
    private String time;
    private boolean soldOut;
    private int availableSeats = 56;

    // Constructor
    public Ticket(String ticketID, String origin, String destination, double price, int seat, String date, String time) {
        this.ticketID = ticketID;
        this.origin = origin;
        this.destination = destination;
        this.price = price;
        this.seat = seat;
        this.date = date;
        this.time = time;
        this.soldOut = false;
    }

    // Getters and Setters
    public String getTicketID() { return ticketID; }
    public void setTicketID(String ticketID) { this.ticketID = ticketID; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getSeat() { return seat; }
    public void setSeat(int seat) { this.seat = seat; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    
    public boolean isSoldOut() { return soldOut; }
    public void setSoldOut(boolean soldOut) { this.soldOut = soldOut; }
    
    public int getAvailableSeats() { return availableSeats; }
    
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }
    
    // Method to decrement available seats
    public void decrementSeats(int seatsToBook) {
        if (seatsToBook <= this.availableSeats) {
            this.availableSeats -= seatsToBook;
            if (this.availableSeats == 0) {
                this.soldOut = true;
            }
        } else {
            throw new IllegalArgumentException("Not enough seats available to book");
        }
    }
    
    public static class CurrencyFormatter {
        public static String formatToRupiah(double amount) {
            NumberFormat formatter = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
            return formatter.format(amount);
        }
    }
}

