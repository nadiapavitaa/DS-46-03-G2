/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

public class MobileBanking extends Payment {
    private String mobileNumber;
    private String bankName;

    // Constructor
    public MobileBanking(String paymentID, double amount, String mobileNumber, String bankName) {
        super(paymentID, amount);
        this.mobileNumber = mobileNumber;
        this.bankName = bankName;
    }

    // Getters and Setters
    public String getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }

    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }

    // Override processPayment
    @Override
    public String processPayment() {
        return "Payment processed using Mobile Banking: " + bankName;
    }
}

