/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;


import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/creditCard")
public class creditCard extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cardNumber = request.getParameter("cardNumber");
        String expiryDate = request.getParameter("expiryDate");
        String cardholderName = request.getParameter("cardholderName");
        String status;
        boolean success = false;

        try {
            // Validasi input
            if (cardNumber == null || cardNumber.isEmpty() || cardNumber.length() != 16) {
                throw new IllegalArgumentException("Invalid Card Number. Must be 16 digits.");
            }
            if (expiryDate == null || expiryDate.isEmpty() || !expiryDate.matches("\\d{2}/\\d{2}")) {
                throw new IllegalArgumentException("Invalid Expiry Date. Format must be MM/YY.");
            }
            if (cardholderName == null || cardholderName.isEmpty()) {
                throw new IllegalArgumentException("Cardholder Name is required.");
            }

            // Simulasi proses pembayaran
            status = "Credit Card Payment Successful! Thank you, " + cardholderName;
            success = true;

        } catch (IllegalArgumentException e) {
            status = "Error: " + e.getMessage();
        }

        // Meneruskan status ke JSP
        request.setAttribute("paymentStatus", status);
        request.setAttribute("success", success);
        RequestDispatcher dispatcher = request.getRequestDispatcher("paymentStatus.jsp");
        dispatcher.forward(request, response);
    }
}