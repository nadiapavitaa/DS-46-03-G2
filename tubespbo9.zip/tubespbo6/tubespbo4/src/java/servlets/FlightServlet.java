/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servlets;

import models.Flight;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/flight")
public class FlightServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String origin = request.getParameter("origin");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date");
        String planeClass = request.getParameter("planeClass");

        // Defaultkan jumlah kursi ke 0 jika parameter tidak valid
        int numberOfSeats = 0;
        try {
            numberOfSeats = Integer.parseInt(request.getParameter("numberOfSeats"));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        List<Flight> flightTickets = Flight.searchTicket(origin, destination, date, planeClass);

        // Hitung total harga untuk setiap tiket
        if (!flightTickets.isEmpty()) {
            for (Flight flight : flightTickets) {
                double totalPrice = Flight.calculateTotalPrice(flight.getPrice(), numberOfSeats);
                flight.setPrice(totalPrice); // Simpan total harga dalam atribut price
            }
        }

        request.setAttribute("flightTickets", flightTickets);
        request.setAttribute("numberOfSeats", numberOfSeats); // Pastikan atribut ini diset

        RequestDispatcher dispatcher = request.getRequestDispatcher("flight.jsp");
        dispatcher.forward(request, response);
    }
}
