/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package models;

import dao.DBconnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Bus extends Ticket {
    private String busID;

    // Constructor
    public Bus(String ticketID, String origin, String destination, double price, int seat, String date, String time, String busID) {
        super(ticketID, origin, destination, price, seat, date, time);
        this.busID = busID;
    }

    // Getters and Setters
    public String getBusID() { return busID; }
    public void setBusID(String busID) { this.busID = busID; }

    // Method to search tickets
    public static List<Bus> searchTicket(String origin, String destination, String date) {
        List<Bus> busTickets = new ArrayList<>();
        String sql = "SELECT * FROM tiket_bus WHERE origin = ? AND destination = ? AND date = ?";

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, origin);
            statement.setString(2, destination);
            statement.setString(3, date);

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                busTickets.add(new Bus(
                    resultSet.getString("ticketID"),
                    resultSet.getString("origin"),
                    resultSet.getString("destination"),
                    resultSet.getDouble("price"),
                    resultSet.getInt("seat"),
                    resultSet.getString("date"),
                    resultSet.getString("time"),
                    resultSet.getString("busID")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return busTickets;
    }

    // Calculate total price
    public static double calculateTotalPrice(double pricePerSeat, int numberOfSeats) {
        return pricePerSeat * numberOfSeats;
    }
}
